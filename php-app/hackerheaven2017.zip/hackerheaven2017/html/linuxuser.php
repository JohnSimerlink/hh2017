<?php

echo exec('whoami');

?>
