<?php

include_once "../../includes/logout.php";

?>